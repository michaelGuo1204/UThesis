# Result

## Machine learning baseline

### R1

| model_type     | metric_type | metric_value |
| :------------- | :---------- | -----------: |
| Baseline       | auc         |          0.5 |
| Decision Tree  | auc         |     0.519481 |
| Linear         | auc         |     0.559809 |
| Xgboost        | auc         |     0.622437 |
| Neural Network | auc         |     0.583903 |
| Random Forest  | auc         |     0.535031 |
| Ensemble       | auc         |     0.622437 |

### R2

| model_type     | metric_type | metric_value |
| :------------- | :---------- | -----------: |
| Baseline       | auc         |          0.5 |
| Decision Tree  | auc         |     0.517931 |
| Linear         | auc         |     0.549794 |
| Xgboost        | auc         |     0.556674 |
| Neural Network | auc         |      0.46388 |
| Random Forest  | auc         |     0.566262 |
| Ensemble       | auc         |     0.577829 |

### R10

| model_type     | metric_type | metric_value |
| :------------- | :---------- | -----------: |
| Baseline       | auc         |          0.5 |
| Decision Tree  | auc         |     0.529015 |
| Linear         | auc         |     0.584224 |
| Xgboost        | auc         |     0.647255 |
| Neural Network | auc         |     0.562013 |
| Random Forest  | auc         |     0.595046 |
| Ensemble       | auc         |     0.647255 |

## EM and GNN

### BASED on R2 (R1 not fittable, R10 poor auc)

![Train Loss](/home/bili/Lernen/UThesis/Result/Train Loss.svg)

![Train acc](/home/bili/Lernen/UThesis/Result/Train acc-16538132447891.svg)

![Val loss](/home/bili/Lernen/UThesis/Result/Val loss.svg)

![Val acc](/home/bili/Lernen/UThesis/Result/Val acc.svg)

![Val auc](/home/bili/Lernen/UThesis/Result/Val auc.svg)

![Test loss](/home/bili/Lernen/UThesis/Result/Test loss.svg)

![Test acc](/home/bili/Lernen/UThesis/Result/Test acc-16538132750752.svg)

![Test auc](/home/bili/Lernen/UThesis/Result/Test auc-16538132796273.svg)

## VEM analysis for No.2 iteration

![MESO](/home/bili/Lernen/UThesis/Result/MESO.svg)

![BestModel](/home/bili/Lernen/UThesis/Result/BestModel.svg)!

[Cluster](/home/bili/Lernen/UThesis/Result/Cluster.svg)

![heatmap_col](/home/bili/Lernen/UThesis/EM/VEM/Cluster/heatmap_col.svg)!

[ClusterCorr](/home/bili/Lernen/UThesis/Result/ClusterCorr.svg)

![heatmap_col](/home/bili/Lernen/UThesis/Result/heatmap_col-16538133849824.svg)

![heatmap_row](/home/bili/Lernen/UThesis/Result/heatmap_row.svg)
